--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1 (Ubuntu 12.1-1.pgdg18.04+1)
-- Dumped by pg_dump version 12.1 (Ubuntu 12.1-1.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE test1;
--
-- Name: test1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE test1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE test1 OWNER TO postgres;

\connect test1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dev_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dev_table (
    id integer NOT NULL,
    dev text NOT NULL,
    tg_id integer NOT NULL
);


ALTER TABLE public.dev_table OWNER TO postgres;

--
-- Name: dev_table_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dev_table_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dev_table_id_seq OWNER TO postgres;

--
-- Name: dev_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dev_table_id_seq OWNED BY public.dev_table.id;


--
-- Name: lstusers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lstusers (
    id integer NOT NULL,
    usname text NOT NULL,
    username text NOT NULL,
    tgid integer NOT NULL
);


ALTER TABLE public.lstusers OWNER TO postgres;

--
-- Name: lstusers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lstusers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lstusers_id_seq OWNER TO postgres;

--
-- Name: lstusers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lstusers_id_seq OWNED BY public.lstusers.id;


--
-- Name: pm_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pm_table (
    id integer NOT NULL,
    pm text NOT NULL,
    tg_id integer NOT NULL
);


ALTER TABLE public.pm_table OWNER TO postgres;

--
-- Name: pm_table_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pm_table_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pm_table_id_seq OWNER TO postgres;

--
-- Name: pm_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pm_table_id_seq OWNED BY public.pm_table.id;


--
-- Name: prj_dev; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prj_dev (
    id integer NOT NULL,
    id_prj integer NOT NULL,
    id_dev integer NOT NULL
);


ALTER TABLE public.prj_dev OWNER TO postgres;

--
-- Name: prj_dev_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.prj_dev_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prj_dev_id_seq OWNER TO postgres;

--
-- Name: prj_dev_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.prj_dev_id_seq OWNED BY public.prj_dev.id;


--
-- Name: prj_pm; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prj_pm (
    id integer NOT NULL,
    id_prj integer NOT NULL,
    id_pm integer NOT NULL
);


ALTER TABLE public.prj_pm OWNER TO postgres;

--
-- Name: prj_pm_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.prj_pm_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prj_pm_id_seq OWNER TO postgres;

--
-- Name: prj_pm_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.prj_pm_id_seq OWNED BY public.prj_pm.id;


--
-- Name: prj_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prj_table (
    id integer NOT NULL,
    prj text NOT NULL
);


ALTER TABLE public.prj_table OWNER TO postgres;

--
-- Name: prj_table_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.prj_table_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prj_table_id_seq OWNER TO postgres;

--
-- Name: prj_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.prj_table_id_seq OWNED BY public.prj_table.id;


--
-- Name: schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule (
    id integer NOT NULL,
    lstdate text NOT NULL,
    id_prj integer NOT NULL,
    id_dev integer NOT NULL,
    hours integer NOT NULL,
    id_pm integer NOT NULL
);


ALTER TABLE public.schedule OWNER TO postgres;

--
-- Name: schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schedule_id_seq OWNER TO postgres;

--
-- Name: schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_id_seq OWNED BY public.schedule.id;


--
-- Name: tblname_colname_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tblname_colname_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tblname_colname_seq OWNER TO postgres;

--
-- Name: dev_table id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dev_table ALTER COLUMN id SET DEFAULT nextval('public.dev_table_id_seq'::regclass);


--
-- Name: lstusers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lstusers ALTER COLUMN id SET DEFAULT nextval('public.lstusers_id_seq'::regclass);


--
-- Name: pm_table id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pm_table ALTER COLUMN id SET DEFAULT nextval('public.pm_table_id_seq'::regclass);


--
-- Name: prj_dev id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prj_dev ALTER COLUMN id SET DEFAULT nextval('public.prj_dev_id_seq'::regclass);


--
-- Name: prj_pm id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prj_pm ALTER COLUMN id SET DEFAULT nextval('public.prj_pm_id_seq'::regclass);


--
-- Name: prj_table id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prj_table ALTER COLUMN id SET DEFAULT nextval('public.prj_table_id_seq'::regclass);


--
-- Name: schedule id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule ALTER COLUMN id SET DEFAULT nextval('public.schedule_id_seq'::regclass);


--
-- Data for Name: dev_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dev_table (id, dev, tg_id) FROM stdin;
\.
COPY public.dev_table (id, dev, tg_id) FROM '$$PATH$$/2979.dat';

--
-- Data for Name: lstusers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lstusers (id, usname, username, tgid) FROM stdin;
\.
COPY public.lstusers (id, usname, username, tgid) FROM '$$PATH$$/2981.dat';

--
-- Data for Name: pm_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pm_table (id, pm, tg_id) FROM stdin;
\.
COPY public.pm_table (id, pm, tg_id) FROM '$$PATH$$/2983.dat';

--
-- Data for Name: prj_dev; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prj_dev (id, id_prj, id_dev) FROM stdin;
\.
COPY public.prj_dev (id, id_prj, id_dev) FROM '$$PATH$$/2985.dat';

--
-- Data for Name: prj_pm; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prj_pm (id, id_prj, id_pm) FROM stdin;
\.
COPY public.prj_pm (id, id_prj, id_pm) FROM '$$PATH$$/2987.dat';

--
-- Data for Name: prj_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prj_table (id, prj) FROM stdin;
\.
COPY public.prj_table (id, prj) FROM '$$PATH$$/2989.dat';

--
-- Data for Name: schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule (id, lstdate, id_prj, id_dev, hours, id_pm) FROM stdin;
\.
COPY public.schedule (id, lstdate, id_prj, id_dev, hours, id_pm) FROM '$$PATH$$/2991.dat';

--
-- Name: dev_table_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dev_table_id_seq', 29, true);


--
-- Name: lstusers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lstusers_id_seq', 29, true);


--
-- Name: pm_table_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pm_table_id_seq', 19, true);


--
-- Name: prj_dev_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.prj_dev_id_seq', 213, true);


--
-- Name: prj_pm_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.prj_pm_id_seq', 19, true);


--
-- Name: prj_table_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.prj_table_id_seq', 20, true);


--
-- Name: schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_id_seq', 1280, true);


--
-- Name: tblname_colname_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tblname_colname_seq', 1, false);


--
-- PostgreSQL database dump complete
--

